from backend.services.document_formatter import format_docx, format_pdf, format_txt
from backend.utils.text_utils import sanitize_text


def test_sanitize_text():
    result = sanitize_text("Hello\u2019s   world\r\n\r\n\r\nNext")
    assert result == "Hello's world\n\nNext"


def test_txt_formatter():
    assert format_txt("Sample legal document") == b"Sample legal document"


def test_docx_formatter():
    result = format_docx(
        "1. INTRODUCTION\nThis is a sample document.",
        "Sample Agreement",
        terms=["Payment within 30 days", "Confidentiality"],
    )
    assert result[:2] == b"PK"


def test_pdf_formatter():
    result = format_pdf("1. INTRODUCTION\nThis is a sample document.", "Sample Agreement")
    assert result.startswith(b"%PDF")
