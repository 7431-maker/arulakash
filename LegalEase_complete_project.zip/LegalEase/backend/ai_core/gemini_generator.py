import os
from typing import Optional
from dotenv import load_dotenv
from backend.utils.text_utils import sanitize_text

load_dotenv()


class GeminiConfigurationError(RuntimeError):
    pass


class GeminiGenerationError(RuntimeError):
    pass


class GeminiDocumentGenerator:
    """Wrapper around Google's current Gen AI Python SDK."""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

        if not self.api_key:
            raise GeminiConfigurationError(
                "GEMINI_API_KEY is not configured. Add it to the .env file."
            )

        try:
            from google import genai
            self.client = genai.Client(api_key=self.api_key)
        except ImportError as exc:
            raise GeminiConfigurationError(
                "The google-genai package is not installed."
            ) from exc
        except Exception as exc:
            raise GeminiConfigurationError(
                f"Could not initialize Gemini client: {exc}"
            ) from exc

    def build_prompt(
        self, document_type, parties, terms, effective_date,
        jurisdiction, additional_instructions=""
    ):
        numbered = "\n".join(
            f"{i}. {term}" for i, term in enumerate(terms, 1)
        )
        return f"""
You are a careful legal-document drafting assistant.

Create a professional legal document draft based only on the information supplied.
Do not invent names, dates, addresses, payment amounts, governing laws, or other
material facts. If a necessary detail is missing, use [TO BE COMPLETED].

Important:
- This is an informational draft, not legal advice.
- Use neutral, professional legal language.
- Do not claim the document is valid in every jurisdiction.
- Keep clauses internally consistent.
- Do not mention that you are an AI.
- Return plain text only, without Markdown code fences.
- Use clear section headings.
- Include signature blocks.
- Include a short Review Notice stating that a qualified legal professional should review the document.

DOCUMENT TYPE:
{document_type}

PARTIES:
{parties}

EFFECTIVE DATE:
{effective_date}

JURISDICTION:
{jurisdiction}

KEY TERMS:
{numbered}

ADDITIONAL INSTRUCTIONS:
{additional_instructions or "None"}

Write the complete draft now.
""".strip()

    def generate_document(
        self, document_type, parties, terms, effective_date,
        jurisdiction="Not specified", additional_instructions=""
    ):
        prompt = self.build_prompt(
            document_type, parties, terms, effective_date,
            jurisdiction, additional_instructions
        )
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
            )
        except Exception as exc:
            raise GeminiGenerationError(f"Gemini generation failed: {exc}") from exc

        text = getattr(response, "text", None)
        if not text:
            raise GeminiGenerationError("Gemini returned an empty response.")
        return sanitize_text(text)
