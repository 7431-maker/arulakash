from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "running"


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_generate_with_mocked_generator(monkeypatch):
    class FakeGenerator:
        model = "test-model"

        def generate_document(self, **kwargs):
            assert kwargs["document_type"] == "Freelance Work Contract"
            return "FREELANCE WORK CONTRACT\n\nPayment within 30 days."

    monkeypatch.setattr("backend.routes.GeminiDocumentGenerator", lambda: FakeGenerator())

    payload = {
        "document_type": "Freelance Work Contract",
        "parties": "Jane Doe, TechNova Inc.",
        "terms": ["Payment within 30 days"],
        "effective_date": "2026-10-04",
        "jurisdiction": "Tamil Nadu, India",
        "additional_instructions": "",
    }
    response = client.post("/generate", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["model"] == "test-model"
    assert "Payment within 30 days" in data["content"]
