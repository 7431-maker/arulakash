import io
import re
from pathlib import Path
from typing import Optional

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt
from fpdf import FPDF

from backend.utils.text_utils import sanitize_text, escape_html

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def format_txt(text: str) -> bytes:
    return sanitize_text(text).encode("utf-8")


def format_html_preview(text: str) -> str:
    safe = escape_html(sanitize_text(text))
    safe = safe.replace("\n\n", "</p><p>").replace("\n", "<br>")
    return f"""<div style="background:#111827;color:#e5e7eb;padding:24px;
border-radius:14px;line-height:1.65;font-family:Arial,sans-serif;
max-height:650px;overflow-y:auto;border:1px solid #374151;"><p>{safe}</p></div>"""


def _add_footer(section, company_name):
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run(
        f"{company_name} | AI-generated informational draft | "
        "Review with a qualified legal professional before use."
    )
    run.font.size = Pt(8)
    run.font.name = "Times New Roman"


def format_docx(
    text: str, doc_type: str, terms: Optional[list[str]] = None,
    logo_path: Optional[str] = None, company_name: str = "LegalEase"
) -> bytes:
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)

    document.styles["Normal"].font.name = "Times New Roman"
    document.styles["Normal"].font.size = Pt(11)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run(doc_type.upper())
    r.bold = True
    r.font.name = "Times New Roman"
    r.font.size = Pt(16)

    sub = document.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sr = sub.add_run(company_name)
    sr.italic = True
    sr.font.size = Pt(10)

    for raw in sanitize_text(text).splitlines():
        line = raw.strip()
        if not line:
            document.add_paragraph()
            continue
        heading = (
            len(line) < 120 and
            (line.isupper() or bool(re.match(r"^\d+[\).\s]+[A-Z]", line))
             or line.endswith(":"))
        )
        if heading:
            p = document.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(4)
            rr = p.add_run(line)
            rr.bold = True
            rr.font.name = "Times New Roman"
            rr.font.size = Pt(12)
        else:
            p = document.add_paragraph(line)
            p.paragraph_format.line_spacing = 1.15
            p.paragraph_format.space_after = Pt(5)

    if terms:
        document.add_page_break()
        h = document.add_paragraph()
        h.add_run("KEY TERMS").bold = True
        table = document.add_table(rows=1, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = "Table Grid"
        table.rows[0].cells[0].text = "No."
        table.rows[0].cells[1].text = "Term"
        for cell in table.rows[0].cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cell.paragraphs:
                for rr in p.runs:
                    rr.bold = True
        for i, term in enumerate(terms, 1):
            cells = table.add_row().cells
            cells[0].text = str(i)
            cells[1].text = term

    document.add_paragraph()
    h = document.add_paragraph()
    h.add_run("SIGNATURES").bold = True
    document.add_paragraph("Party 1: ______________________________    Date: ______________")
    document.add_paragraph("Party 2: ______________________________    Date: ______________")
    _add_footer(section, company_name)

    out = io.BytesIO()
    document.save(out)
    return out.getvalue()


class BrandedPDF(FPDF):
    def __init__(self, company_name):
        super().__init__()
        self.company_name = company_name
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.cell(self.epw, 7, self.company_name, align="C")
        self.ln(8)

    def footer(self):
        self.set_y(-14)
        self.set_font("Helvetica", "", 7)
        self.cell(
            self.epw, 6,
            f"{self.company_name} | AI-generated informational draft | Page {self.page_no()}",
            align="C",
        )


def format_pdf(text: str, doc_type: str, company_name: str = "LegalEase") -> bytes:
    pdf = BrandedPDF(company_name)
    pdf.add_page()
    pdf.set_margins(18, 18, 18)
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(pdf.epw, 9, doc_type.upper(), align="C")
    pdf.set_font("Helvetica", "I", 9)
    pdf.multi_cell(pdf.epw, 6, company_name, align="C")
    pdf.ln(5)

    for raw in sanitize_text(text).splitlines():
        line = raw.strip()
        if not line:
            pdf.ln(3)
            continue
        heading = (
            len(line) < 120 and
            (line.isupper() or bool(re.match(r"^\d+[\).\s]+[A-Z]", line))
             or line.endswith(":"))
        )
        if heading:
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(pdf.epw, 7, line)
        else:
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(pdf.epw, 6, line)
        pdf.ln(1)

    pdf.set_font("Helvetica", "B", 11)
    pdf.multi_cell(pdf.epw, 7, "SIGNATURES")
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(pdf.epw, 8, "Party 1: ______________________________    Date: ______________")
    pdf.multi_cell(pdf.epw, 8, "Party 2: ______________________________    Date: ______________")
    return bytes(pdf.output(dest="S"))
