import html
import os
import re
from datetime import date

import requests
import streamlit as st
from dotenv import load_dotenv

from backend.services.document_formatter import format_docx, format_html_preview, format_pdf, format_txt

load_dotenv()

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)

API_URL = os.getenv("FRONTEND_API_URL", "http://127.0.0.1:8000").rstrip("/")
APP_NAME = os.getenv("APP_NAME", "LegalEase")
COMPANY_NAME = os.getenv("COMPANY_NAME", "LegalEase")

st.markdown(
    """
    <style>
    .main-title{text-align:center;font-size:42px;font-weight:800;margin-bottom:0}
    .subtitle{text-align:center;color:#94a3b8;margin:4px 0 24px}
    .notice{background:#172033;border:1px solid #334155;border-radius:12px;padding:14px;margin-bottom:18px}
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(f'<div class="main-title">⚖️ {html.escape(APP_NAME)}</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered legal document drafting workspace</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="notice"><strong>Important:</strong> LegalEase creates informational drafts, not legal advice. '
    'Review generated documents with a qualified legal professional before signing or using them.</div>',
    unsafe_allow_html=True,
)

if "generated_text" not in st.session_state:
    st.session_state.generated_text = ""
if "generated_type" not in st.session_state:
    st.session_state.generated_type = "Legal Document"
if "model" not in st.session_state:
    st.session_state.model = ""

with st.sidebar:
    st.header("Document Details")
    document_type = st.selectbox(
        "Document Type",
        [
            "Employment Contract",
            "Non-Disclosure Agreement (NDA)",
            "Lease Agreement",
            "Freelance Work Contract",
            "Service Agreement",
            "Employment Offer Letter",
            "General Agreement",
            "Custom Legal Document",
        ],
    )
    parties = st.text_area(
        "Parties Involved",
        placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=110,
    )
    terms_text = st.text_area(
        "Terms & Conditions",
        placeholder="Payment to be made within 30 days of invoice;\nConfidentiality must be maintained;",
        height=180,
        help="Separate terms with semicolons or new lines.",
    )
    effective_date = st.date_input("Effective Date", value=date.today())
    jurisdiction = st.text_input("Jurisdiction", value="Not specified")
    additional_instructions = st.text_area("Additional Instructions", height=100)
    generate = st.button("✨ Generate Document", type="primary", use_container_width=True)

if generate:
    terms = [x.strip() for x in terms_text.replace("\n", ";").split(";") if x.strip()]
    if not parties.strip():
        st.error("Please enter the parties involved.")
    elif not terms:
        st.error("Please enter at least one term.")
    else:
        payload = {
            "document_type": document_type,
            "parties": parties.strip(),
            "terms": terms,
            "effective_date": effective_date.isoformat(),
            "jurisdiction": jurisdiction.strip() or "Not specified",
            "additional_instructions": additional_instructions.strip(),
        }
        with st.spinner("Generating your legal draft..."):
            try:
                response = requests.post(f"{API_URL}/generate", json=payload, timeout=120)
                response.raise_for_status()
                data = response.json()
                st.session_state.generated_text = data["content"]
                st.session_state.generated_type = data["document_type"]
                st.session_state.model = data["model"]
            except requests.exceptions.ConnectionError:
                st.error("Could not connect to FastAPI. Start the backend first.")
            except requests.exceptions.HTTPError:
                try:
                    detail = response.json().get("detail", "Unknown API error")
                except Exception:
                    detail = "Unknown API error"
                st.error(f"API error: {detail}")
            except requests.exceptions.RequestException as exc:
                st.error(f"Request failed: {exc}")

if st.session_state.generated_text:
    st.subheader("Document Preview")
    tab_preview, tab_edit, tab_export = st.tabs(["👁️ Preview", "✏️ Edit", "⬇️ Export"])

    with tab_preview:
        st.markdown(format_html_preview(st.session_state.generated_text), unsafe_allow_html=True)
        if st.session_state.model:
            st.caption(f"Generated with model: {st.session_state.model}")

    with tab_edit:
        edited = st.text_area(
            "Edit Document",
            value=st.session_state.generated_text,
            height=650,
            key="document_editor",
        )
        if st.button("Save Edits", type="primary"):
            st.session_state.generated_text = edited
            st.success("Edits saved for this session.")

    with tab_export:
        current_text = st.session_state.generated_text
        current_type = st.session_state.generated_type
        safe_name = re.sub(r"[^a-zA-Z0-9_-]+", "_", current_type.lower()).strip("_")

        c1, c2, c3 = st.columns(3)
        with c1:
            st.download_button("Download TXT", format_txt(current_text),
                               file_name=f"{safe_name}.txt", mime="text/plain",
                               use_container_width=True)
        with c2:
            st.download_button(
                "Download DOCX",
                format_docx(current_text, current_type,
                            terms=[x.strip() for x in terms_text.replace("\n", ";").split(";") if x.strip()],
                            company_name=COMPANY_NAME),
                file_name=f"{safe_name}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True,
            )
        with c3:
            st.download_button(
                "Download PDF",
                format_pdf(current_text, current_type, company_name=COMPANY_NAME),
                file_name=f"{safe_name}.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
else:
    st.info("Enter document details in the sidebar and click Generate Document.")
