from fastapi import APIRouter, HTTPException

from backend.ai_core.gemini_generator import (
    GeminiConfigurationError,
    GeminiDocumentGenerator,
    GeminiGenerationError,
)
from backend.schemas import DocumentRequest, DocumentResponse, HealthResponse

router = APIRouter()
DISCLAIMER = (
    "LegalEase provides AI-generated informational drafts and does not provide legal advice. "
    "Review the document with a qualified legal professional before signing or relying on it."
)


@router.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(status="ok", service="LegalEase API")


@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    try:
        generator = GeminiDocumentGenerator()
        content = generator.generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            effective_date=request.effective_date,
            jurisdiction=request.jurisdiction,
            additional_instructions=request.additional_instructions,
        )
        return DocumentResponse(
            document_type=request.document_type,
            content=content,
            model=generator.model,
            disclaimer=DISCLAIMER,
        )
    except GeminiConfigurationError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except GeminiGenerationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {exc}") from exc
