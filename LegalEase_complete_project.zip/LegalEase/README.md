# LegalEase — AI-Powered Legal Document Generator

Complete local full-stack implementation based on the supplied LegalEase project documentation.

## Architecture

Streamlit frontend -> FastAPI backend -> Gemini AI -> editable document -> TXT/DOCX/PDF

## Features

- Employment contracts, NDAs, lease agreements, service agreements and custom drafts.
- Inputs for document type, parties, terms, effective date and jurisdiction.
- Gemini-powered generation.
- Editable generated document.
- Dark HTML preview.
- TXT, DOCX and PDF downloads.
- DOCX terms table and footer.
- PDF header/footer.
- FastAPI health endpoint.
- Automated tests with the AI layer mocked.

> LegalEase creates informational drafts and is not legal advice. Review generated documents with a qualified legal professional before signing or relying on them.

## Setup

1. Install Python 3.10+. Python 3.11/3.12 is recommended.
2. Open this folder in VS Code.
3. Create a virtual environment:

Windows PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows CMD:
```cmd
python -m venv .venv
.venv\Scriptsctivate
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

4. Install:
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5. Copy `.env.example` to `.env` and put your Gemini API key into `GEMINI_API_KEY`.

6. Start backend:
```bash
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

7. In a second terminal, start frontend:
```bash
streamlit run frontend/app.py
```

8. Open `http://localhost:8501`.

Backend docs: `http://127.0.0.1:8000/docs`
Health: `http://127.0.0.1:8000/health`

## Test

```bash
pytest -q
```

Tests mock Gemini and therefore do not consume API quota.

## Troubleshooting

If the frontend cannot connect, make sure FastAPI is running and `FRONTEND_API_URL` is correct.

If Gemini fails, verify the API key and choose a model available to your Google AI account in `GEMINI_MODEL`.

Do not commit `.env`.

## Production hardening

Before handling real confidential legal information, add authentication, HTTPS, rate limiting, persistent storage, audit logging, jurisdiction-specific templates, access controls, and a privacy policy.
